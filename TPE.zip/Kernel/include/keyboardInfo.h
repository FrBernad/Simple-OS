#ifndef KEYBOARD_INFO_H
#define KEYBOARD_INFO_H

#include <stdint.h>

uint8_t hasKey(void);
uint8_t getKey(void);

#endif