#ifndef COLOURS_H
#define COLOURS_H

#define RGB 3
typedef enum {
      BLACK = 0x000000,
      WHITE = 0xFFFFFF,
      RED = 0x00FFFF
}t_colour;

#endif