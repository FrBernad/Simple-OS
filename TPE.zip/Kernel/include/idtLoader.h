#ifndef _IDTLOADER_H_
#define _IDTLOADER_H_

void load_idt();

#endif