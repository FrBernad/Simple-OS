#ifndef TIMER_TICK_H
#define TIMER_TICK_H

void timerHandler();
int ticksElapsed();
int secondsElapsed();

#endif
