#include <stringLib.h>
#include <systemCalls.h>
#include <utils.h>

char getchar(){
      return sys_getchar();
}

void printString(char * str, uint8_t newLine) {
      sys_write(str,strlen(str));
      if (newLine) {
            sys_newLine();
      }
}

void putchar(char c){
      sys_write(&c,1);
}

void printNum(uint64_t num, uint8_t base) {
      char buffer[10];
      uintToBase(num, buffer, base);
      printString(buffer, 0);
}

void clear(){  
      sys_clear();
}

void newLine(){
      sys_newLine();
}
void deletechar(){ 
      sys_deletechar();
}

void staticputchar(char c){
      sys_staticwrite(&c,1);
}

int strlen(char * str){
      int size = 0;
      for (int i = 0; str[i] != 0; i++) {
            size++;
      }
      return size;
}
