#include <commands.h>
#include <systemCalls.h>
#include <stringLib.h>
#include <utils.h>
#include <shell.h>
#include <registers.h>
#include <cpuInfo.h>
#include <RTCTime.h>

void help() {
      printString("These shell commands are defined internally.  Type 'help' to see this list.", 1);
      printString(" >inforeg: prints the value of all the registers on screen", 1);
      printString(" >printmem: recieves a pointer and makes a memory dump of 32 bytes on screen", 1);
      printString(" >time: prints the current system time on screen", 1);
      printString(" >cpuid: prints the processor brand and model on screen", 1);
      printString(" >temp: prints the current processor temperature on screen", 1);
      printString(" >changeUsername: changes the shell prompt username", 1);
}

void inforeg() {
      t_register registers[REGISTERS];
      sys_inforeg(registers);
      for (int i = 0; i < REGISTERS; i++) {
            printString(" > ", 0);
            printString(registers[i].name, 0);
            putchar(':');
            printNum(registers[i].data, 16);
            newLine();
      }
}

void time(){
      uint8_t hours = sys_RTCTime(HOURS);
      uint8_t mins = sys_RTCTime(MINUTES);
      uint8_t secs = sys_RTCTime(SECONDS);
      printString("Time -> ", 0);
      printNum(hours, 10);
      putchar(':');
      printNum(mins, 10);
      putchar(':');
      printNum(secs, 10);
      newLine();
}

void cpuInfo() {
      char cpuVendor[10]={0};
      t_cpuInfo cpuInfo = {cpuVendor,0};
      sys_cpuInfo(&cpuInfo);
      printString(" > CPU Vendor: ", 0);
      printString(cpuInfo.cpuVendor, 1);
      printString(" > CPU model: ", 0);
      printNum(cpuInfo.model, 10);
      newLine();
}

void printmem(uint64_t mem){
      //
}

void cpuTemp() {
      printString("CPU temp:  ", 0);
      printNum(sys_temp(),10);
      printString("C ",1);
}
