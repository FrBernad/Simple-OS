#include <applications.h>

t_application shell = {SHELL, SCREEN_1};
t_application calculator = {CALCULATOR, SCREEN_0};