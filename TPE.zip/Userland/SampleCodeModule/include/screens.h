#ifndef SCREENS_H
#define SCREENS_H

typedef enum {
      SCREEN_0 = 0,
      SCREEN_1 = 1
} t_screenID;

#endif
