#ifndef STRING_LIB_H
#define STRING_LIB_H

#include <stdint.h>

void printString(char* str, uint8_t newLine);
void printNum(uint64_t num, uint8_t base);
void putchar(char c);
void staticputchar(char c);
char getchar();
void deletechar();
void newLine();
int strlen(char* str);

#endif