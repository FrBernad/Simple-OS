#ifndef CALCULATOR_H
#define CALCULATOR_H

void runCalculator();
void evaluate(char *expression);

#endif