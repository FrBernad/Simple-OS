#ifndef APP_MANAGER_H
#define APP_MANAGER_H

#include <applications.h>

#define MAX_APPS 2

void startApplication();
void changeApplication(const t_application app);

#endif