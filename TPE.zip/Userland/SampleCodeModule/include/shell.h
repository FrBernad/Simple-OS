#ifndef SHELL_H
#define SHELL_H

#include <buffer.h>

void runShell();

#endif