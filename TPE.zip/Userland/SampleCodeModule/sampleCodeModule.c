#include <appManager.h>

int main() {
      startApplication();
return 0;
}